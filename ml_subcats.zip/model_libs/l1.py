print(s)
print('checking subcat')